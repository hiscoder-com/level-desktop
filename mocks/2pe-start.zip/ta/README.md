# Russian translationAcademy

Академия построена на основании 13го издания на английском. Сегодня уже вышло 15е английское издание. За это время в разделе **translate** появились новые статьи: 
1. [choose-style](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/choose-style/title.md) [choose-style](https://git.door43.org/ru_gl/ru_ta/src/branch/master/translate/choose-style/title.md)
1. [translate-useultust](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/translate-useultust/title.md)
1. [grammar-connect-condition-fact](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/grammar-connect-condition-fact/title.md)
1. [grammar-connect-condition-contrary](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/grammar-connect-condition-contrary/title.md)
1. [grammar-connect-condition-hypothetical](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/grammar-connect-condition-hypothetical/title.md)
1. [figs-orderHeb](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/figs-orderHeb/title.md)
1. [figs-orderGrk](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/figs-orderGrk/title.md)
1. [figs-simetaphor](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/figs-simetaphor/title.md)
1. [figs-cometaphor](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/figs-cometaphor/title.md)
1. [translate-blessing](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/translate-blessing/title.md)
1. [figs-crowd](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/figs-crowd/title.md)
1. [figs-imperative3p](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/figs-imperative3p/title.md)
1. [grammar-collectivenouns](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/grammar-collectivenouns/title.md)
1. [translate-key-terms](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/translate-key-terms/title.md)
1. [translate-kinship](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/translate-kinship/title.md)
1. [writing-oathformula](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/writing-oathformula/title.md)
1. [writing-politeness](https://git.door43.org/unfoldingWord/en_ta/src/branch/master/translate/writing-politeness/title.md)

Не был переведен заголовок и вопрос к статье: 
1. [grammar-connect-time-sequential](https://git.door43.org/ru_gl/ru_ta/src/branch/master/translate/grammar-connect-time-sequential)

Не был переведен вопрос к статье:
1. [grammar-connect-words-phrases](https://git.door43.org/ru_gl/ru_ta/src/branch/master/translate/grammar-connect-words-phrases)
1. [grammar-connect-time-simultaneous](https://git.door43.org/ru_gl/ru_ta/src/branch/master/translate/grammar-connect-time-simultaneous)
1. [grammar-connect-time-background](https://git.door43.org/ru_gl/ru_ta/src/branch/master/translate/grammar-connect-time-background)
1. [grammar-connect-exceptions](https://git.door43.org/ru_gl/ru_ta/src/branch/master/translate/grammar-connect-exceptions)

[Посмотреть Академию в одном файле](https://cdn.door43.org/u/ru_gl/ru_ta/master/print_all.html)